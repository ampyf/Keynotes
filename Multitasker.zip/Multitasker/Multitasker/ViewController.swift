//
//  ViewController.swift
//  Multitasker
//
//  Created by Ampy 2 on 3/15/16.
//  Copyright © 2016 AF. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        
        print("\n" + __FUNCTION__)
        print("Width: \(size.width) Height: \(size.height)")
    }

    override func willTransitionToTraitCollection(newCollection: UITraitCollection, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        print("\n" + __FUNCTION__)
        print("horizontalSizeClass: \(newCollection.horizontalSizeClass.description()) verticalSizeClass: \(newCollection.verticalSizeClass.description())")
    }
    
    
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillShow:"), name:UIKeyboardWillShowNotification, object: nil);
        NSNotificationCenter.defaultCenter().addObserver(self, selector: Selector("keyboardWillHide:"), name:UIKeyboardWillHideNotification, object: nil);
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self);
    }
    
    func keyboardWillShow(sender: NSNotification) {
        // 
        
        self.view.frame.origin.y = -250
    }
    
    func keyboardWillHide(sender: NSNotification) {
        self.view.frame.origin.y = 0
    }

    
}

extension UIUserInterfaceSizeClass {
    func description() -> String {
        switch (self) {
        case .Unspecified : return "Unspecified"
        case .Compact : return "Compact"
        case .Regular : return "Regular"
        }
    }
}


