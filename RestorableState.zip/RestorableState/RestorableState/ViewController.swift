//
//  ViewController.swift
//  RestorableState
//
//  Created by Ampy 2 on 3/16/16.
//  Copyright © 2016 AF. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let colorArray = [UIColor.redColor(), UIColor.yellowColor(), UIColor.greenColor(),UIColor.blueColor()]
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("Cell", forIndexPath: indexPath)
        cell.backgroundColor = colorArray[indexPath.row]
        
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        switch traitCollection.horizontalSizeClass {
        case .Regular : return CGSizeMake(self.collectionView.bounds.width/4, self.collectionView.bounds.height)
        case .Compact : return CGSizeMake(self.collectionView.bounds.width, self.collectionView.bounds.height)
        case .Unspecified : return CGSizeZero
        }
    }
}
